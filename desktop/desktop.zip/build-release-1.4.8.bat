@echo off
setlocal
cd /d "%~dp0.."

echo [1/5] Dung cac tien trinh cu...
taskkill /F /IM "KTC Production Control.exe" >nul 2>&1
taskkill /F /IM electron.exe >nul 2>&1

echo [2/5] Don build cu...
rmdir /S /Q frontend\dist >nul 2>&1
rmdir /S /Q desktop\frontend >nul 2>&1
rmdir /S /Q desktop\release >nul 2>&1

echo [3/5] Build frontend...
cd frontend
call npm ci
if errorlevel 1 exit /b 1
call npm run typecheck
if errorlevel 1 exit /b 1
call npm run build
if errorlevel 1 exit /b 1

echo [4/5] Build Desktop 1.4.8...
cd ..\desktop
call npm ci
if errorlevel 1 exit /b 1
call npm rebuild electron
if errorlevel 1 exit /b 1
call npm run dist:win
if errorlevel 1 exit /b 1

echo [5/5] Ket qua:
dir /S /B release\*.exe
endlocal
