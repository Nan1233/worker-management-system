const path = require('node:path');
const fs = require('node:fs/promises');
const ExcelJS = require('exceljs');
const JSZip = require('jszip');

const PROCESS_SHEETS = Object.freeze({
  CAN: { sheet: 'CÁN', headerRows: [133], dataStart: 134, core: { sequence:1, workerCode:2, workerName:3, shift:4, machine:5, totalTime:6, product:8, actualOutput:10, workDate:12, totalNg:14 }, defects:[16,19], deductions:[26,31] },
  EP: { sheet: 'EP', headerRows: [173], dataStart: 174, core: { workerCode:2, workerName:3, shift:4, machine:5, deductionTotal:6, totalTime:7, product:9, actualOutput:11, totalNg:15 }, defects:[16,22], deductions:[23,31] },
  XLBV: { sheet: 'XLBV', headerPattern: /nhập mã số cn/i, headerColumn:2, blockHeaderMin:200, core: { sequence:1, workerCode:2, workerName:3, shift:11, deductionTotal:7, ok:10, totalTime:11, actualTime:12, product:13, standardOutput:15, actualOutput:16, totalNg:20 }, defects:[22,31] },
  GC: { sheet: 'Cắt lồng', headerPattern: /ngày\s*\/\s*tháng/i, headerColumn:31, core: { sequence:1, workerCode:2, workerName:3, machine:4, shift:5, training:6, totalTime:7, actualTime:8, deductionTotal:10, product:27, standardOutput:28, actualOutput:29, workDate:31, ok:33, totalNg:34 }, deductions:[11,26], defects:[36,54] },
  MAI: { sheet: 'TT Mài', headerPattern: /^ngày$/i, headerColumn:36, core: { sequence:1, workerCode:2, workerName:3, shift:4, machine:5, training:8, actualTime:9, totalTime:10, deductionTotal:11, product:32, standardOutput:33, actualOutput:34, workDate:36, ok:38, totalNg:39 }, deductions:[12,31], defects:[40,46] },
  DO: { sheet: 'TT Đo', headerPattern: /^ngày$/i, headerColumn:32, core: { sequence:1, workerCode:2, workerName:3, shift:4, machine:5, training:7, totalTime:8, actualTime:9, deductionTotal:10, product:28, standardOutput:29, actualOutput:30, workDate:32, ok:34, totalNg:35 }, deductions:[11,27], defects:[37,49] },
  K1: { sheet: 'TT Kiểm 1', headerRows:[208], dataStart:209, core: { sequence:1, workerCode:2, workerName:3, product:4, totalTime:14, standardOutput:15, actualOutput:16, ok:20, totalNg:21 }, deductions:[9,13], defects:[23,56] },
  K2: { sheet: 'TT Kiểm 2', headerRows:[2], dataStart:3, core: { sequence:1, workerCode:2, workerName:3, training:4, deductionTotal:5, totalTime:22, actualTime:23, product:24, standardOutput:25, actualOutput:26, workDate:28, ok:30, totalNg:31 }, deductions:[6,20], defects:[33,80] },
  SX3: { sheet: 'sx3', headerRows:[3], dataStart:6, core: { sequence:1, workDate:2, workerName:3, workerCode:4, shift:5, product:7, totalTime:8, actualTime:9, ok:39, totalNg:40 }, defects:[42,70] }
});

const n = (value) => { const x = Number(value); return Number.isFinite(x) ? x : 0; };
const text = (value) => String(value ?? '').trim();
const normalize = (value) => text(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').replace(/[^a-z0-9]+/gi,' ').trim().toUpperCase();
const dateKey = (value) => {
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}/.test(value)) return value.slice(0,10);
  const d = new Date(value); if (Number.isNaN(d.getTime())) return '';
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
};
const excelDate = (value) => { const k=dateKey(value); if(!k) return null; const [y,m,d]=k.split('-').map(Number); return new Date(y,m-1,d); };
const formatDateLabel = (value) => { const k=dateKey(value); if(!k) return ''; const [y,m,d]=k.split('-'); return `${d}/${m}/${y}`; };
const columnLetter = (value) => { let number=Number(value); let result=''; while(number>0){ const remainder=(number-1)%26; result=String.fromCharCode(65+remainder)+result; number=Math.floor((number-1)/26); } return result; };

function safeCellText(cell) {
  if (!cell) return '';
  const value = cell.value;
  if (value == null) return '';
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (value instanceof Date) return dateKey(value);
  if (Array.isArray(value.richText)) return value.richText.map((part) => text(part && part.text)).join('');
  if (value.formula != null || value.sharedFormula != null) return text(value.result);
  if (value.hyperlink != null) return text(value.text || value.hyperlink);
  if (value.text != null) return text(value.text);
  if (value.result != null) return text(value.result);
  try { return String(value); } catch { return ''; }
}

async function resolveTemplatePath(appPath, fileName) {
  const safeAppPath = typeof appPath === 'string' && appPath.trim() ? appPath : path.join(__dirname, '..');
  const resourcesPath = typeof process.resourcesPath === 'string' ? process.resourcesPath : '';
  const candidates = [
    path.join(safeAppPath, 'assets', 'templates', fileName),
    path.join(resourcesPath, 'assets', 'templates', fileName),
    path.join(__dirname, '..', 'assets', 'templates', fileName)
  ];
  for (const candidate of candidates) {
    try { await fs.access(candidate); return candidate; } catch { /* try next */ }
  }
  throw new Error(`Không tìm thấy file mẫu ${fileName}: ${candidates.join(' | ')}`);
}

const getReportTemplatePath = (appPath) => resolveTemplatePath(
  appPath,
  'Bao-cao-san-xuat-08-2026_CHI_TIET.xlsx'
);

const getReconciliationTemplatePath = (appPath) => resolveTemplatePath(
  appPath,
  'Du-lieu-doi-chieu-08-2026_CHI_TIET.xlsx'
);


function columnToNumber(column) {
  let value = 0;
  for (const char of String(column || '').toUpperCase()) {
    if (char < 'A' || char > 'Z') continue;
    value = value * 26 + (char.charCodeAt(0) - 64);
  }
  return value;
}

function numberToColumn(number) {
  let value = Number(number) || 0;
  let result = '';
  while (value > 0) {
    value -= 1;
    result = String.fromCharCode(65 + (value % 26)) + result;
    value = Math.floor(value / 26);
  }
  return result || 'A';
}

function parseMergeRef(ref) {
  const match = /^([A-Z]+)(\d+):([A-Z]+)(\d+)$/i.exec(String(ref || '').trim());
  if (!match) return null;
  const left = columnToNumber(match[1]);
  const top = Number(match[2]);
  const right = columnToNumber(match[3]);
  const bottom = Number(match[4]);
  if (![left, top, right, bottom].every(Number.isFinite)) return null;
  return {
    left: Math.min(left, right),
    top: Math.min(top, bottom),
    right: Math.max(left, right),
    bottom: Math.max(top, bottom)
  };
}

function mergeRef(range) {
  return `${numberToColumn(range.left)}${range.top}:${numberToColumn(range.right)}${range.bottom}`;
}

function rangesOverlap(a, b) {
  return !(
    a.right < b.left ||
    b.right < a.left ||
    a.bottom < b.top ||
    b.bottom < a.top
  );
}

function normalizeMergeRanges(refs) {
  const ranges = refs.map(parseMergeRef).filter(Boolean);
  const normalized = [];

  for (const currentRange of ranges) {
    let current = { ...currentRange };
    let merged = true;

    while (merged) {
      merged = false;
      for (let index = normalized.length - 1; index >= 0; index -= 1) {
        const existing = normalized[index];
        if (!rangesOverlap(existing, current)) continue;

        current = {
          left: Math.min(existing.left, current.left),
          top: Math.min(existing.top, current.top),
          right: Math.max(existing.right, current.right),
          bottom: Math.max(existing.bottom, current.bottom)
        };
        normalized.splice(index, 1);
        merged = true;
      }
    }

    normalized.push(current);
  }

  return normalized
    .sort((a, b) => a.top - b.top || a.left - b.left || a.bottom - b.bottom || a.right - b.right)
    .map(mergeRef);
}

async function sanitizeWorkbookXml(buffer, label) {
  const zip = await JSZip.loadAsync(buffer);
  const xmlNames = Object.keys(zip.files).filter((name) =>
    /^xl\/(?:workbook\.xml|worksheets\/sheet\d+\.xml|styles\.xml|sharedStrings\.xml)$/i.test(name)
  );
  let changed = false;

  for (const xmlName of xmlNames) {
    const entry = zip.file(xmlName);
    if (!entry) continue;
    let xml = await entry.async('string');
    const originalXml = xml;

    // ExcelJS không nhận ổn định các phần SpreadsheetML dùng tiền tố x:.
    // Đưa namespace chính về namespace mặc định như workbook Excel chuẩn.
    if (/xmlns:x=["']http:\/\/schemas\.openxmlformats\.org\/spreadsheetml\/2006\/main["']/.test(xml)) {
      xml = xml.replace(
        /xmlns:x=["']http:\/\/schemas\.openxmlformats\.org\/spreadsheetml\/2006\/main["']/,
        'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
      );
      xml = xml.replace(/<(\/?)x:/g, '<$1');
    }

    // Chỉ worksheet mới có mergeCells.
    if (/^xl\/worksheets\/sheet\d+\.xml$/i.test(xmlName)) {
      const blockPattern = /<((?:[A-Za-z_][\w.-]*:)?mergeCells)\b[^>]*>([\s\S]*?)<\/\1>/i;
      const blockMatch = blockPattern.exec(xml);
      if (blockMatch) {
        const mergeCellPattern = /<((?:[A-Za-z_][\w.-]*:)?mergeCell)\b[^>]*\bref=["']([^"']+)["'][^>]*\/?\s*>/gi;
        const refs = [];
        let match;
        let tagName = 'mergeCell';
        while ((match = mergeCellPattern.exec(blockMatch[2])) !== null) {
          tagName = match[1] || tagName;
          refs.push(match[2]);
        }

        if (refs.length >= 2) {
          const normalizedRefs = normalizeMergeRanges(refs);
          if (!(normalizedRefs.length === refs.length && normalizedRefs.every((ref, index) => ref === refs[index]))) {
            const mergeCellsTag = blockMatch[1];
            const replacement = `<${mergeCellsTag} count="${normalizedRefs.length}">` +
              normalizedRefs.map((ref) => `<${tagName} ref="${ref}"/>`).join('') +
              `</${mergeCellsTag}>`;
            xml = xml.slice(0, blockMatch.index) + replacement + xml.slice(blockMatch.index + blockMatch[0].length);
          }
        }
      }
    }

    if (xml !== originalXml) {
      zip.file(xmlName, xml);
      changed = true;
    }
  }

  // Chuẩn hóa Content Types. Các file được tạo bởi một số thư viện khai báo
  // Default .xml là workbook, khiến ExcelJS không xác định được workbook part và
  // phát sinh lỗi `Cannot read properties of undefined (reading 'sheets')`.
  const contentTypesName = '[Content_Types].xml';
  const contentTypesEntry = zip.file(contentTypesName);
  if (contentTypesEntry) {
    let contentTypesXml = await contentTypesEntry.async('string');
    const originalContentTypesXml = contentTypesXml;

    contentTypesXml = contentTypesXml.replace(
      /<Default\s+Extension=["']xml["']\s+ContentType=["'][^"']+["']\s*\/>/i,
      '<Default Extension="xml" ContentType="application/xml"/>'
    );

    if (!/PartName=["']\/xl\/workbook\.xml["']/i.test(contentTypesXml)) {
      contentTypesXml = contentTypesXml.replace(
        /<\/Types>\s*$/i,
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/></Types>'
      );
    }

    if (contentTypesXml !== originalContentTypesXml) {
      zip.file(contentTypesName, contentTypesXml);
      changed = true;
    }
  }

  // Chuẩn hóa relationship gốc của package.
  const packageRelsName = '_rels/.rels';
  const packageRelsEntry = zip.file(packageRelsName);
  if (packageRelsEntry) {
    let packageRelsXml = await packageRelsEntry.async('string');
    const originalPackageRelsXml = packageRelsXml;
    packageRelsXml = packageRelsXml.replace(
      /Target=["']\/xl\/workbook\.xml["']/gi,
      'Target="xl/workbook.xml"'
    );
    if (packageRelsXml !== originalPackageRelsXml) {
      zip.file(packageRelsName, packageRelsXml);
      changed = true;
    }
  }

  // Chuẩn hóa đường dẫn relationship tuyệt đối thành đường dẫn tương đối chuẩn OOXML.
  const relsName = 'xl/_rels/workbook.xml.rels';
  const relsEntry = zip.file(relsName);
  if (relsEntry) {
    let relsXml = await relsEntry.async('string');
    const originalRelsXml = relsXml;
    relsXml = relsXml
      .replace(/Target=["']\/xl\/worksheets\//g, 'Target="worksheets/')
      .replace(/Target=["']\/xl\/theme\//g, 'Target="theme/')
      .replace(/Target=["']\/xl\//g, 'Target="');
    if (relsXml !== originalRelsXml) {
      zip.file(relsName, relsXml);
      changed = true;
    }
  }

  if (!changed) return buffer;
  console.warn(`[KTC] Đã chuẩn hóa namespace/merge OOXML trong ${label}.`);
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
}

async function loadTemplateWorkbook(templatePath, label) {
  if (typeof templatePath !== 'string' || !templatePath.trim()) {
    throw new Error(`Đường dẫn ${label} không hợp lệ.`);
  }

  let buffer;
  try {
    buffer = await fs.readFile(templatePath);
  } catch (error) {
    throw new Error(`Không đọc được ${label}: ${templatePath}. ${error?.message || error}`);
  }

  if (!Buffer.isBuffer(buffer) || buffer.length < 1024) {
    throw new Error(`${label} rỗng hoặc không hợp lệ: ${templatePath}`);
  }

  // Ưu tiên đọc nguyên template chuẩn. Việc tiền xử lý OOXML chỉ là fallback
  // cho các file cũ; không được sửa XML của template đã được Excel/LibreOffice
  // lưu lại đúng chuẩn vì có thể làm mất liên kết sheet và gây lỗi sheetNo.
  let workbook = new ExcelJS.Workbook();
  try {
    await workbook.xlsx.load(buffer);
  } catch (directError) {
    try {
      const safeBuffer = await sanitizeWorkbookXml(buffer, label);
      workbook = new ExcelJS.Workbook();
      await workbook.xlsx.load(safeBuffer);
    } catch (fallbackError) {
      const directMessage = directError?.message || String(directError);
      const fallbackMessage = fallbackError?.message || String(fallbackError);
      throw new Error(
        `Không mở được ${label}: ${path.basename(templatePath)}. ` +
        `Đọc trực tiếp: ${directMessage}. Fallback: ${fallbackMessage}`
      );
    }
  }

  if (!Array.isArray(workbook.worksheets) || workbook.worksheets.length === 0) {
    throw new Error(`${label} không có worksheet hợp lệ: ${path.basename(templatePath)}`);
  }

  return workbook;
}

function findHeaderRows(sheet, cfg) {
  if (cfg.headerRows) return cfg.headerRows.filter((row) => row <= sheet.rowCount);
  const rows=[];
  for(let r=1;r<=sheet.rowCount;r+=1){
    const value=safeCellText(sheet.getRow(r).getCell(cfg.headerColumn));
    if(cfg.headerPattern.test(text(value)) && (!cfg.blockHeaderMin || r>=cfg.blockHeaderMin)) rows.push(r);
  }
  return rows;
}

function blocksForSheet(sheet, cfg) {
  const headers=findHeaderRows(sheet,cfg);
  if(!headers.length) return [{headerRow:1,startRow:cfg.dataStart||2,endRow:sheet.rowCount}];
  return headers.map((headerRow,index)=>({
    headerRow,
    startRow: cfg.dataStart && headers.length===1 ? cfg.dataStart : headerRow+1,
    endRow: (headers[index+1] || Math.max(sheet.rowCount+1, headerRow+102))-1
  }));
}

function setInput(row, column, value, numFmt) {
  if(!column) return;
  const cell=row.getCell(column);
  if(cell.value && typeof cell.value==='object' && (cell.value.formula || cell.value.sharedFormula)) return;
  cell.value=value;
  if(numFmt) cell.numFmt=numFmt;
}

function detailValue(items, typeId, valueKey, typeKey) {
  return (items||[]).filter(x=>Number(x[typeKey])===Number(typeId)).reduce((s,x)=>s+n(x[valueKey]),0);
}

function clearInputRange(sheet, block, cfg) {
  const columns=new Set(Object.values(cfg.core||{}));
  for(const rangeName of ['deductions','defects']){
    const range=cfg[rangeName]; if(!range) continue;
    for(let c=range[0];c<=range[1];c+=1) columns.add(c);
  }
  columns.add(1);
  for(let r=block.startRow;r<=block.endRow;r+=1){
    const row=sheet.getRow(r);
    for(const c of columns){
      const cell=row.getCell(c);
      if(!(cell.value && typeof cell.value==='object' && (cell.value.formula || cell.value.sharedFormula))) cell.value=null;
    }
  }
}

function buildTypeColumnMap(sheet, block, range, types, kind) {
  const map = new Map();
  if (!range || !types.length) return map;
  const headerStart = Math.max(1, block.headerRow - 4);
  const headerEnd = Math.max(block.headerRow, block.startRow - 1);
  for (let column = range[0]; column <= range[1]; column += 1) {
    const labels = [];
    for (let row = headerStart; row <= headerEnd; row += 1) {
      const label = safeCellText(sheet.getRow(row).getCell(column));
      if (label) labels.push(label);
    }
    const normalizedHeader = normalize(labels.join(' '));
    if (!normalizedHeader) continue;
    for (const type of types) {
      const label = typeLabel(type, kind);
      const normalizedLabel = normalize(label);
      if (!normalizedLabel || map.has(Number(type.id))) continue;
      if (normalizedHeader.includes(normalizedLabel) || normalizedLabel.includes(normalizedHeader)) {
        map.set(Number(type.id), column);
      }
    }
  }
  return map;
}

function resolveDetailColumns(sheet, block, cfg, deductionTypes, defectTypes) {
  const deductionColumns = buildTypeColumnMap(sheet, block, cfg.deductions, deductionTypes, 'deduction');
  const defectColumns = buildTypeColumnMap(sheet, block, cfg.defects, defectTypes, 'defect');

  // Với mẫu cũ chưa ghi tên rõ ở từng cột, dùng thứ tự danh mục làm fallback.
  if (cfg.deductions) {
    deductionTypes.slice(0, cfg.deductions[1] - cfg.deductions[0] + 1).forEach((type, index) => {
      if (!deductionColumns.has(Number(type.id))) deductionColumns.set(Number(type.id), cfg.deductions[0] + index);
    });
  }
  if (cfg.defects) {
    defectTypes.slice(0, cfg.defects[1] - cfg.defects[0] + 1).forEach((type, index) => {
      if (!defectColumns.has(Number(type.id))) defectColumns.set(Number(type.id), cfg.defects[0] + index);
    });
  }
  return { deductionColumns, defectColumns };
}

function writeReport(sheet,rowNumber,report,cfg,sequence,deductionTypes,defectTypes,detailColumns){
  const row=sheet.getRow(rowNumber); const c=cfg.core||{};
  setInput(row,c.sequence,sequence);
  setInput(row,c.workerCode,text(report.worker_code));
  setInput(row,c.workerName,text(report.full_name));
  setInput(row,c.shift,text(report.shift));
  setInput(row,c.machine,text(report.machine_no||report.machine_code));
  setInput(row,c.training,n(report.training_percent||100)/100,'0%');
  setInput(row,c.totalTime,n(report.total_time),'0.00');
  setInput(row,c.actualTime,n(report.actual_time),'0.00');
  setInput(row,c.deductionTotal,n(report.deduction_time),'0.00');
  setInput(row,c.product,text(report.product_code||report.product_name));
  setInput(row,c.standardOutput,n(report.standard_output),'#,##0.00');
  setInput(row,c.actualOutput,n(report.actual_output ?? (n(report.tt_ok)+n(report.tt_ng))),'#,##0');
  setInput(row,c.workDate,excelDate(report.work_date),'dd/mm/yyyy');
  setInput(row,c.ok,n(report.tt_ok),'#,##0');
  setInput(row,c.totalNg,n(report.tt_ng),'#,##0');
  for (const type of deductionTypes) {
    const column = detailColumns?.deductionColumns?.get(Number(type.id));
    if (column) setInput(row,column,detailValue(report.deductions,type.id,'hours','deduction_type_id'),'0.00');
  }
  for (const type of defectTypes) {
    const column = detailColumns?.defectColumns?.get(Number(type.id));
    if (column) setInput(row,column,detailValue(report.defects,type.id,'quantity','defect_type_id'),'#,##0');
  }
}

function markDateRow(sheet, rowNumber, workDate) {
  // Chỉ điền ngày vào cột A của dòng phân cách; tuyệt đối không dựng lại
  // màu sắc, chiều cao, ô gộp hoặc bố cục của file mẫu.
  const cell = sheet.getRow(rowNumber).getCell(1);
  if (!(cell.value && typeof cell.value === 'object' && (cell.value.formula || cell.value.sharedFormula))) {
    cell.value = excelDate(workDate);
    cell.numFmt = 'dd/mm/yyyy';
  }
}

function groupByDate(reports) {
  const groups=[];
  let current=null;
  for(const report of reports){
    const key=dateKey(report.work_date);
    if(!key) continue;
    if(!current || current.date!==key){ current={date:key,reports:[]}; groups.push(current); }
    current.reports.push(report);
  }
  return groups;
}

function writeGroupedReportsToTemplate(sheet, cfg, reports, deductionTypes, defectTypes) {
  const blocks=blocksForSheet(sheet,cfg);
  blocks.forEach((block)=>clearInputRange(sheet,block,cfg));
  const groups=groupByDate(reports);
  let written=0;
  const skipped=[];

  groups.forEach((group,groupIndex)=>{
    let block;
    if(blocks.length>1){
      const day=Math.max(1,Number(group.date.slice(8,10))||1);
      block=blocks[Math.min(day-1,blocks.length-1)];
    } else {
      block=blocks[0];
    }

    let rowNumber;
    if(blocks.length>1){
      rowNumber=block.startRow;
    } else {
      rowNumber=block.startRow;
      for(let i=0;i<groupIndex;i+=1) rowNumber+=1+groups[i].reports.length;
    }

    if(rowNumber>block.endRow){ skipped.push({date:group.date,count:group.reports.length,reason:'Không đủ dòng mẫu'}); return; }
    markDateRow(sheet,rowNumber,group.date);
    rowNumber+=1;

    group.reports.forEach((report,index)=>{
      if(rowNumber>block.endRow){ skipped.push({date:group.date,id:report.id,reason:'Vượt vùng dữ liệu mẫu'}); return; }
      const detailColumns = resolveDetailColumns(sheet, block, cfg, deductionTypes, defectTypes);
      writeReport(sheet,rowNumber,report,cfg,index+1,deductionTypes,defectTypes,detailColumns);
      rowNumber+=1;
      written+=1;
    });
  });

  return {written,skipped,dateGroups:groups.length};
}

function updateMonthLabels(workbook, yearMonth){
  const [year,month]=yearMonth.split('-');
  for(const sheet of workbook.worksheets){
    for(let r=1;r<=Math.min(sheet.rowCount,15);r+=1){
      const row=sheet.getRow(r);
      for(let c=1;c<=Math.min(sheet.columnCount,20);c+=1){
        const cell=row.getCell(c);
        const currentText=safeCellText(cell);
        if(typeof cell.value!=='string' || !currentText) continue;
        cell.value=currentText
          .replace(/THÁNG\s+\d{1,2}[\/-]\d{4}/gi,`THÁNG ${month}-${year}`)
          .replace(/THÁNG\s+\d{1,2}/gi,`THÁNG ${Number(month)}`);
      }
    }
  }
}

function internalizeExternalFormulas(workbook){
  const aliases=[
    [/\[[^\]]+\]TỔNG ĐIỂM/gi,'Nhân sự'],
    [/\[[^\]]+\]KẾ HOẠCH/gi,'Yêu cầu'],
    [/\[[^\]]+\]ĐỊNH MỨC/gi,'ĐỊNH MỨC sx1']
  ];
  let changed=0;
  for(const sheet of workbook.worksheets){
    sheet.eachRow({includeEmpty:false},row=>row.eachCell({includeEmpty:false},cell=>{
      if(!cell.value || typeof cell.value!=='object' || typeof cell.value.formula!=='string') return;
      let formula=cell.value.formula;
      for(const [pattern,replacement] of aliases) formula=formula.replace(pattern,replacement);
      if(formula!==cell.value.formula){ cell.value={...cell.value,formula}; changed+=1; }
    }));
  }
  return changed;
}

function typeLabel(type, kind) {
  if(kind==='deduction') return text(type.name || type.deduction_name || type.code || type.deduction_code || `Trừ giờ ${type.id}`);
  return text(type.defect_name || type.name || type.defect_code || type.code || `NG ${type.id}`);
}

function collectGlobalTypes(processPayload, propertyName, kind) {
  const map=new Map();
  for(const data of Object.values(processPayload||{})){
    for(const type of data?.[propertyName]||[]){
      const label=typeLabel(type,kind);
      const key=normalize(label);
      if(!key || map.has(key)) continue;
      map.set(key,{key,label});
    }
  }
  return [...map.values()];
}

function detailMap(items, kind) {
  const map=new Map();
  for(const item of items||[]){
    const label=kind==='deduction'
      ? text(item.deduction_name || item.name || item.deduction_code || item.code)
      : text(item.defect_name || item.name || item.defect_code || item.code);
    const key=normalize(label);
    if(!key) continue;
    const value=kind==='deduction' ? n(item.hours) : n(item.quantity);
    map.set(key,(map.get(key)||0)+value);
  }
  return map;
}

function flattenReports(processPayload) {
  const rows=[];
  for (const [processCode, data] of Object.entries(processPayload || {})) {
    for (const report of data?.reports || []) {
      rows.push({
        processCode,
        id: report.id,
        workDate: dateKey(report.work_date),
        entryDate: dateKey(report.entry_date || report.created_at || report.work_date),
        workerCode: text(report.worker_code),
        workerName: text(report.full_name),
        shift: text(report.shift),
        machine: text(report.machine_no || report.machine_code),
        product: text(report.product_code || report.product_name),
        totalTime: n(report.total_time),
        actualTime: n(report.actual_time),
        deductionTime: n(report.deduction_time),
        standardOutput: n(report.standard_output),
        trainingPercent: n(report.training_percent || 100),
        actualOutput: n(report.actual_output ?? (n(report.tt_ok) + n(report.tt_ng))),
        ok: n(report.tt_ok),
        ng: n(report.tt_ng),
        spPerHour: n(report.output_per_hour || report.actual_output_per_hour || report.sp_per_hour),
        achievementRate: n(report.achievement_rate || report.performance_rate || report.rate),
        deductionMap: detailMap(report.deductions,'deduction'),
        defectMap: detailMap(report.defects,'defect'),
        status: text(report.status || 'approved')
      });
    }
  }
  rows.sort((a,b)=>a.workDate.localeCompare(b.workDate)||a.processCode.localeCompare(b.processCode)||Number(a.id)-Number(b.id));
  return rows;
}

function detailedHeaders({includeId,deductionTypes,defectTypes}) {
  const headers=[];
  if(includeId) headers.push('ID báo cáo'); else headers.push('STT');
  headers.push('Ngày','Công đoạn','Mã NV','Tên NV','Ca','Máy','Mã SP','TG làm việc','TG thực tế','Tổng TG trừ','Định mức','Sản lượng','OK','Tổng NG','SP/giờ','Tỷ lệ đạt');
  deductionTypes.forEach((type)=>headers.push(`Trừ giờ - ${type.label}`));
  defectTypes.forEach((type)=>headers.push(`NG - ${type.label}`));
  headers.push('Trạng thái');
  return headers;
}

function detailedRow(item,{includeId,sequence,deductionTypes,defectTypes}) {
  const values=[];
  values.push(includeId ? item.id : sequence);
  values.push(excelDate(item.workDate),item.processCode,item.workerCode,item.workerName,item.shift,item.machine,item.product,item.totalTime,item.actualTime,item.deductionTime,item.standardOutput,item.actualOutput,item.ok,item.ng,item.spPerHour,item.achievementRate);
  deductionTypes.forEach((type)=>values.push(item.deductionMap.get(type.key)||0));
  defectTypes.forEach((type)=>values.push(item.defectMap.get(type.key)||0));
  values.push(item.status);
  return values;
}

function styleHeader(row, color='FF1F4E78') {
  row.font={bold:true,color:{argb:'FFFFFFFF'}};
  row.fill={type:'pattern',pattern:'solid',fgColor:{argb:color}};
  row.alignment={vertical:'middle',horizontal:'center',wrapText:true};
  row.height=38;
}

function styleDetailedSheet(sheet, columnCount) {
  sheet.views=[{state:'frozen',ySplit:1}];
  sheet.autoFilter={from:'A1',to:`${columnLetter(columnCount)}1`};
  styleHeader(sheet.getRow(1));
  for(let c=1;c<=columnCount;c+=1){
    const header=text(sheet.getCell(1,c).value);
    let width=12;
    if(/Tên NV/i.test(header)) width=24;
    else if(/Mã SP|Máy/i.test(header)) width=16;
    else if(/Trừ giờ|NG -/i.test(header)) width=15;
    else if(/Trạng thái/i.test(header)) width=13;
    sheet.getColumn(c).width=width;
  }
  sheet.getColumn(2).numFmt='dd/mm/yyyy';
  for(let c=9;c<=columnCount;c+=1){
    if(/Trạng thái/i.test(text(sheet.getCell(1,c).value))) continue;
    sheet.getColumn(c).numFmt='#,##0.00';
  }
}

function addGroupedProcessSheet(workbook, processCode, rows, deductionTypes, defectTypes) {
  const sheet=workbook.addWorksheet(processCode);
  const headers=detailedHeaders({includeId:false,deductionTypes,defectTypes});
  sheet.addRow(headers);
  styleDetailedSheet(sheet,headers.length);
  const groups=groupByDate(rows.map((item)=>({work_date:item.workDate,item})));
  for(const group of groups){
    const dateRow=sheet.addRow([excelDate(group.date),`DỮ LIỆU NGÀY ${formatDateLabel(group.date)}`]);
    dateRow.getCell(1).numFmt='dd/mm/yyyy';
    dateRow.font={bold:true,color:{argb:'FF1F4E78'}};
    dateRow.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FFD9EAF7'}};
    dateRow.alignment={vertical:'middle'};
    group.reports.forEach((wrapped,index)=>{
      const row=sheet.addRow(detailedRow(wrapped.item,{includeId:false,sequence:index+1,deductionTypes,defectTypes}));
      row.getCell(2).numFmt='dd/mm/yyyy';
    });
  }
  return sheet;
}


function normalizedHeader(cell) {
  return normalize(safeCellText(cell));
}

function findHeaderColumnMap(sheet, rowNumber) {
  const map = new Map();
  const row = sheet.getRow(rowNumber);
  for (let column = 1; column <= sheet.columnCount; column += 1) {
    const label = normalizedHeader(row.getCell(column));
    if (label && !map.has(label)) map.set(label, column);
  }
  return map;
}

function firstColumnMatching(headerMap, patterns) {
  for (const [label, column] of headerMap.entries()) {
    if (patterns.some((pattern) => pattern.test(label))) return column;
  }
  return 0;
}

function copyRowPresentation(sheet, sourceRowNumber, targetRowNumber) {
  const source = sheet.getRow(sourceRowNumber);
  const target = sheet.getRow(targetRowNumber);
  target.height = source.height;
  for (let column = 1; column <= sheet.columnCount; column += 1) {
    const from = source.getCell(column);
    const to = target.getCell(column);
    to.style = JSON.parse(JSON.stringify(from.style || {}));
    if (from.numFmt) to.numFmt = from.numFmt;
  }
}

function findTotalRow(sheet, startRow) {
  for (let rowNumber = startRow; rowNumber <= sheet.rowCount; rowNumber += 1) {
    const label = normalize(safeCellText(sheet.getRow(rowNumber).getCell(1)));
    if (label.includes('TONG CONG')) return rowNumber;
  }
  return sheet.rowCount + 1;
}

function detailByHeader(item, header, kind) {
  const source = kind === 'deduction' ? item.deductionMap : item.defectMap;
  const prefix = kind === 'deduction' ? /^(TRU GIO|TG TRU|CHI TIET THOI GIAN TRU)\s*-?\s*/ : /^(NG|LOI NG|CHI TIET NG)\s*-?\s*/;
  const key = normalize(header).replace(prefix, '').trim();
  if (!key) return 0;
  if (source.has(key)) return source.get(key) || 0;
  for (const [candidate, value] of source.entries()) {
    if (candidate.includes(key) || key.includes(candidate)) return value || 0;
  }
  return 0;
}

function templateValueForHeader(item, header, sequence, processCode) {
  const key = normalize(header);
  if (/^(ID|ID BAO CAO)$/.test(key)) return item.id;
  if (/^STT$/.test(key)) return sequence;
  if (/^NGAY NHAP|NGAY THANG/.test(key)) return excelDate(item.entryDate || item.workDate);
  if (/^NGAY$/.test(key)) return excelDate(item.workDate);
  if (/CONG DOAN/.test(key)) return processCode || item.processCode;
  if (/MA NV|MA SO NV|MA CONG NHAN/.test(key)) return item.workerCode;
  if (/TEN NV|TEN CONG NHAN/.test(key)) return item.workerName;
  if (/^CA$/.test(key)) return item.shift;
  if (/MAY/.test(key) && !/LOI MAY/.test(key)) return item.machine;
  if (/MA SP|SAN PHAM/.test(key)) return item.product;
  if (/DINH MUC/.test(key)) return item.standardOutput;
  if (/TG LAM VIEC|THOI GIAN LAM VIEC/.test(key)) return item.totalTime;
  if (/TG THUC TE|THOI GIAN THUC TE/.test(key)) return item.actualTime;
  if (/TONG TG TRU|TONG THOI GIAN TRU/.test(key)) return item.deductionTime;
  if (/SAN LUONG|THUC TICH|KET QUA SX/.test(key) && !/KE HOACH/.test(key)) return item.actualOutput;
  if (/^OK$|TONG OK|SO LUONG OK/.test(key)) return item.ok;
  if (/TONG NG/.test(key)) return item.ng;
  if (/SP GIO|SO SP H/.test(key)) return item.spPerHour;
  if (/TY LE DAT|PHAN TRAM DAT/.test(key)) return item.achievementRate;
  if (/TRANG THAI/.test(key)) return item.status;
  if (/^(TRU GIO|TG TRU)|THIEU SP|BAT MAY|CHUYEN MA|CHINH MAY|CHO HANG|5S|GIAO CA|HOC VIEC|BAO DUONG|MAT DIEN|MAT KHI/.test(key)) {
    return detailByHeader(item, header, 'deduction');
  }
  if (/^(NG|LOI)|KQD|BAVIA|CAO SU|CAT LEM|RACH|NUT|VO|KICH THUOC|PPCM|CSH|FURE|LAN CS/.test(key)) {
    return detailByHeader(item, header, 'defect');
  }
  return null;
}

function clearRows(sheet, startRow, endRow) {
  for (let rowNumber = startRow; rowNumber <= endRow; rowNumber += 1) {
    const row = sheet.getRow(rowNumber);
    for (let column = 1; column <= sheet.columnCount; column += 1) row.getCell(column).value = null;
  }
}

function writeFlatTemplateRows(sheet, headerRow, startRow, items, { includeId = false, grouped = false, processCode = '' } = {}) {
  const headerCells = sheet.getRow(headerRow);
  const originalTotalRow = findTotalRow(sheet, startRow);
  const availableDataRows = Math.max(0, originalTotalRow - startRow);
  const groups = grouped ? groupByDate(items.map((item) => ({ ...item, work_date: item.workDate }))) : [];
  const requiredRows = grouped
    ? items.length + Math.max(0, groups.length - 1)
    : items.length;
  const desiredRows = Math.max(requiredRows, 1);

  if (desiredRows > availableDataRows) {
    sheet.spliceRows(originalTotalRow, 0, ...Array.from({ length: desiredRows - availableDataRows }, () => []));
  } else if (desiredRows < availableDataRows) {
    sheet.spliceRows(startRow + desiredRows, availableDataRows - desiredRows);
  }

  const totalRow = findTotalRow(sheet, startRow);
  const styleSource = startRow;
  for (let rowNumber = startRow; rowNumber < totalRow; rowNumber += 1) copyRowPresentation(sheet, styleSource, rowNumber);
  clearRows(sheet, startRow, totalRow - 1);

  let rowNumber = startRow;
  let sequence = 1;
  let lastDate = '';
  for (const item of items) {
    if (grouped && lastDate && item.workDate !== lastDate) {
      rowNumber += 1;
      sequence = 1;
    }
    const row = sheet.getRow(rowNumber);
    for (let column = 1; column <= sheet.columnCount; column += 1) {
      const header = safeCellText(headerCells.getCell(column));
      const value = templateValueForHeader(item, header, sequence, processCode);
      if (value === null || value === undefined) continue;
      row.getCell(column).value = value;
      const normalized = normalize(header);
      if (/^NGAY|NGAY THANG/.test(normalized)) row.getCell(column).numFmt = 'dd/mm/yyyy';
      if (/TY LE/.test(normalized)) row.getCell(column).numFmt = '0.00%';
    }
    lastDate = item.workDate;
    sequence += 1;
    rowNumber += 1;
  }

  const finalTotalRow = findTotalRow(sheet, startRow);
  const total = sheet.getRow(finalTotalRow);
  total.getCell(1).value = 'TỔNG CỘNG';
  for (let column = 2; column <= sheet.columnCount; column += 1) {
    const header = normalize(safeCellText(headerCells.getCell(column)));
    if (/TG|THOI GIAN|SAN LUONG|OK|NG|SP GIO/.test(header) && !/^NGAY/.test(header)) {
      const letter = columnLetter(column);
      total.getCell(column).value = { formula: `SUM(${letter}${startRow}:${letter}${Math.max(startRow, finalTotalRow - 1)})` };
    }
  }
  return { written: items.length, totalRow: finalTotalRow };
}

function updateSimpleTemplateLabels(workbook, yearMonth, dataFileName = '') {
  const [year, month] = yearMonth.split('-');
  for (const sheet of workbook.worksheets) {
    for (let rowNumber = 1; rowNumber <= Math.min(sheet.rowCount, 15); rowNumber += 1) {
      const row = sheet.getRow(rowNumber);
      for (let column = 1; column <= Math.min(sheet.columnCount, 20); column += 1) {
        const cell = row.getCell(column);
        if (typeof cell.value !== 'string') continue;
        let value = cell.value
          .replace(/08\/2026/g, `${month}/${year}`)
          .replace(/THÁNG\s+08\s+NĂM\s+2026/gi, `THÁNG ${month} NĂM ${year}`)
          .replace(/THÁNG\s+08\/2026/gi, `THÁNG ${month}/${year}`);
        if (dataFileName && /Du-lieu-doi-chieu-\d{2}-\d{4}/i.test(value)) value = value.replace(/Du-lieu-doi-chieu-\d{2}-\d{4}(?:_CHI_TIET)?\.xlsx/gi, dataFileName);
        cell.value = value;
      }
    }
  }
}
async function buildReconciliationWorkbook({appPath,date,payload}) {
  const yearMonth=date.slice(0,7); const [year,month]=yearMonth.split('-');
  const fileName=`Du-lieu-doi-chieu-${month}-${year}_CHI_TIET.xlsx`;
  const templatePath=await getReconciliationTemplatePath(appPath);
  const workbook=await loadTemplateWorkbook(templatePath,'template dữ liệu đối chiếu');
  updateSimpleTemplateLabels(workbook,yearMonth);

  const processPayload=payload?.processes||{};
  const allRows=flattenReports(processPayload);
  const dataSheet=workbook.getWorksheet('DATA_DB');
  if(!dataSheet) throw new Error('Template đối chiếu thiếu sheet DATA_DB');
  writeFlatTemplateRows(dataSheet,1,2,allRows,{includeId:true,grouped:false});

  const sheetMap={GC:'Cắt lồng',MAI:'TT Mài'};
  for(const [processCode,sheetName] of Object.entries(sheetMap)){
    const sheet=workbook.getWorksheet(sheetName);
    if(!sheet) continue;
    const rows=allRows.filter((item)=>item.processCode===processCode);
    writeFlatTemplateRows(sheet,1,2,rows,{grouped:true,processCode});
  }

  const check=workbook.getWorksheet('ĐỐI CHIẾU');
  if(check){
    const rows=[['Gia công','GC'],['Mài','MAI']];
    rows.forEach(([label,code],index)=>{
      const rowNumber=4+index;
      const items=allRows.filter((item)=>item.processCode===code);
      check.getCell(rowNumber,1).value=label;
      check.getCell(rowNumber,2).value=items.length;
      check.getCell(rowNumber,3).value=items.reduce((sum,item)=>sum+item.ok,0);
      check.getCell(rowNumber,4).value=items.reduce((sum,item)=>sum+item.ng,0);
      check.getCell(rowNumber,5).value=items.reduce((sum,item)=>sum+item.actualOutput,0);
      check.getCell(rowNumber,6).value=items.reduce((sum,item)=>sum+item.actualTime,0);
      check.getCell(rowNumber,7).value=0;
      check.getCell(rowNumber,8).value='Khớp';
    });
  }

  workbook.calcProperties.fullCalcOnLoad=true;
  workbook.calcProperties.forceFullCalc=true;
  return {buffer:Buffer.from(await workbook.xlsx.writeBuffer()),fileName,yearMonth,rowCount:allRows.length,templateFile:path.basename(templatePath)};
}

function addReportReconciliationSheet(workbook, dataFileName) {
  const old=workbook.getWorksheet('KIỂM TRA ĐỐI CHIẾU');
  if(old) workbook.removeWorksheet(old.id);
  const sheet=workbook.addWorksheet('KIỂM TRA ĐỐI CHIẾU');
  sheet.addRow(['Công đoạn','Số dòng dữ liệu','Tổng sản lượng','Tổng OK','Tổng NG','Ghi chú']);
  Object.keys(PROCESS_SHEETS).forEach((processCode,index)=>{
    const row=index+2;
    sheet.getCell(row,1).value=processCode;
    sheet.getCell(row,2).value={formula:`COUNTIF('[${dataFileName}]DATA_DB'!$C:$C,A${row})`};
    sheet.getCell(row,3).value={formula:`SUMIF('[${dataFileName}]DATA_DB'!$C:$C,A${row},'[${dataFileName}]DATA_DB'!$M:$M)`};
    sheet.getCell(row,4).value={formula:`SUMIF('[${dataFileName}]DATA_DB'!$C:$C,A${row},'[${dataFileName}]DATA_DB'!$N:$N)`};
    sheet.getCell(row,5).value={formula:`SUMIF('[${dataFileName}]DATA_DB'!$C:$C,A${row},'[${dataFileName}]DATA_DB'!$O:$O)`};
    sheet.getCell(row,6).value='Đối chiếu với file dữ liệu cùng thư mục';
  });
  styleHeader(sheet.getRow(1),'FFC65911');
  [18,18,18,14,14,38].forEach((width,index)=>{sheet.getColumn(index+1).width=width;});
  sheet.views=[{state:'frozen',ySplit:1}];
}

async function buildMonthlyWorkbookLocal({appPath,date,payload}){
  const yearMonth=date.slice(0,7); const [year,month]=yearMonth.split('-');
  const dataFileName=`Du-lieu-doi-chieu-${month}-${year}_CHI_TIET.xlsx`;
  const templatePath=await getReportTemplatePath(appPath);
  const workbook=await loadTemplateWorkbook(templatePath,'template báo cáo sản xuất');
  updateSimpleTemplateLabels(workbook,yearMonth,dataFileName);

  const processPayload=payload?.processes||{};
  const allRows=flattenReports(processPayload);
  const results=[];
  const sheetMap={GC:'Cắt lồng',MAI:'TT Mài'};
  for(const [processCode,sheetName] of Object.entries(sheetMap)){
    const sheet=workbook.getWorksheet(sheetName);
    if(!sheet){results.push({processCode,sheet:sheetName,success:false,error:'Thiếu sheet mẫu'});continue;}
    const reports=allRows.filter((item)=>item.processCode===processCode);
    const result=writeFlatTemplateRows(sheet,6,7,reports,{grouped:true,processCode});
    results.push({processCode,sheet:sheetName,success:true,reportCount:reports.length,...result});
  }

  const cover=workbook.getWorksheet('Bìa');
  if(cover){
    cover.getCell('B7').value=`${month}/${year}`;
    cover.getCell('B8').value=dataFileName;
    cover.getCell('B9').value=new Date();
    cover.getCell('B9').numFmt='dd/mm/yyyy';
  }
  const check=workbook.getWorksheet('KIỂM TRA ĐỐI CHIẾU');
  if(check){
    const rows=[['Gia công','GC'],['Mài','MAI']];
    rows.forEach(([label,code],index)=>{
      const rowNumber=5+index;
      const items=allRows.filter((item)=>item.processCode===code);
      const count=items.length;
      const ok=items.reduce((sum,item)=>sum+item.ok,0);
      const ng=items.reduce((sum,item)=>sum+item.ng,0);
      check.getCell(rowNumber,1).value=label;
      check.getCell(rowNumber,2).value=count;
      check.getCell(rowNumber,3).value=count;
      check.getCell(rowNumber,4).value=ok;
      check.getCell(rowNumber,5).value=ok;
      check.getCell(rowNumber,6).value=ng;
      check.getCell(rowNumber,7).value=ng;
      check.getCell(rowNumber,8).value=0;
      check.getCell(rowNumber,9).value='Khớp';
    });
    check.getCell('B9').value=dataFileName;
  }

  workbook.calcProperties.fullCalcOnLoad=true;
  workbook.calcProperties.forceFullCalc=true;
  const buffer=Buffer.from(await workbook.xlsx.writeBuffer());
  return {buffer,fileName:`Bao-cao-san-xuat-${month}-${year}_CHI_TIET.xlsx`,yearMonth,results,formulaReplacementCount:0,templateFile:path.basename(templatePath)};
}

module.exports={buildMonthlyWorkbookLocal,buildReconciliationWorkbook,PROCESS_SHEETS};
