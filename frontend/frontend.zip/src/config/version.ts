export const FRONTEND_VERSION = String(import.meta.env.VITE_BUILD_VERSION || "1.5.0");
export const FRONTEND_COMMIT_SHA = String(import.meta.env.VITE_COMMIT_SHA || "local");
export const API_VERSION = String(import.meta.env.VITE_API_VERSION || "1");
